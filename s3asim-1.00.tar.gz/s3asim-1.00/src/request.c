/* (C) Northwestern University
 * See COPYING in the top-level directory . */

#include "request.h"

const char *decode_req[MAX_REQ] = 
    {
	"WORK_REQ"
    };
