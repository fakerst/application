#pragma once

#ifndef _PDS_DISLOCATIONNETWORK_H
#define _PDS_DISLOCATIONNETWORK_H

void Remove2Nodes(Home_t *home);
void SplitZeroPairs(Home_t *home);
void JunctionsLength(Home_t *home);

#endif
